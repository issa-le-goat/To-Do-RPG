package Functions

import (
	"database/sql"
	"net/http"
	"github.com/gin-gonic/gin"
	"strconv"
)

// RegisterInput définit ce qu'on attend du client pour une inscription
type RegisterInput struct {
	Name     string `json:"name" binding:"required"`
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required"`
}

type LoginInput struct {
	Identifier string `json:"identifier" binding:"required"`
	Password   string `json:"password" binding:"required"`
}

type DeleteUserInput struct {
	UserID int `json:"user_id"`
}
type TaskInput struct {
	UserID      int    `json:"user_id"` // Correspond à la colonne ID_User
	Name        string `json:"name"`
	Description string `json:"description"`
	DueDate     string `json:"due_date"` // Correspond à la colonne Due_Date (type datetime en SQL)
	Duration    int    `json:"duration"`   // Correspond à l'enum ('todo', 'done')
	Priority    int    `json:"priority"`
}

type TaskDeleteInput struct {
	TaskID int `json:"task_id"`
	UserID int `json:"user_id"`
}


//////////////////////////////////////////////////////////////////////////////// handlers pour les post /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

func RegisterHandler(c *gin.Context, db *sql.DB) {
	var input RegisterInput

	// Étape 1 : Lire et valider le JSON
	// ShouldBindJSON vérifie si les données reçues correspondent à RegisterInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Données invalides ou incomplètes"})
		return // On arrête tout si les données sont mauvaises
	}

	// Étape 2 : Appeler ta base de données
	// On utilise la fonction CreateUser que tu as déjà codée
	newID, err := CreateUser(db, input.Name, input.Password, input.Email)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Impossible de créer l'utilisateur"})
		return
	}

	// Étape 3 : Renvoyer la réponse de succès
	c.JSON(http.StatusCreated, gin.H{
		"message": "Utilisateur créé avec succès",
		"userID":  newID,
	})
}

func LoginHandler(c *gin.Context, db *sql.DB) {
	var input LoginInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Données invalides ou incomplètes"})
		return
	}

	user, err := Login(db, input.Identifier, input.Password)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Identifiants incorrects"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "Connexion réussie",
		"userId": user,
	})
}

func CreateTaskHandler(c *gin.Context, db *sql.DB) {
	var task TaskInput

	if err := c.ShouldBindJSON(&task); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Données invalides ou incomplètes"})
		return
	}

	CreateTask(db, task.UserID, task.Name, task.Duration, task.Priority, task.DueDate, task.Description)

	c.JSON(http.StatusCreated, gin.H{"message": "Tâche créée avec succès"})
}

func DeleteTaskHandler(c *gin.Context, db *sql.DB) {
	var input TaskDeleteInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Données invalides ou incomplètes"})
		return
	}

	err := DeleteTask(db, input.TaskID, input.UserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Impossible de supprimer la tâche"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Tâche supprimée avec succès"})
}

func DeleteUserHandler(c *gin.Context, db *sql.DB) {
	var input DeleteUserInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Données invalides ou incomplètes"})
		return
	}

	err := DeleteUser(db, input.UserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Impossible de supprimer l'utilisateur"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Utilisateur supprimé avec succès"})
}

/////////////////////////////////////////////////////////////////////////// handlers pour les get ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

func GetTasksHandler(c *gin.Context, db *sql.DB) {
	// Ici tu pourrais lire un paramètre d'URL pour filtrer les tâches d'un utilisateur, par exemple ?user_id=123
	userID := c.Query("user_id")

	IntID, err := strconv.Atoi(userID)
	
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Erreur : la chaîne ne contient pas un nombre valide."})
		return
	}
	
	fetchTasks, err := GetTasksByID(db, IntID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Impossible de récupérer les tâches"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"tasks": fetchTasks})
}

func GetLeaderboardHandler(c *gin.Context, db *sql.DB) {
    // Appel de la fonction de logique métier définie précédemment
    leaderboard, err := GetLeaderboard(db)
    if err != nil {
        // En cas d'erreur serveur, on renvoie un statut 500
        c.JSON(http.StatusInternalServerError, gin.H{
            "error": "Impossible de récupérer le classement",
        })
        return
    }

    // Succès : on renvoie la liste au format JSON
    c.JSON(http.StatusOK, gin.H{
        "leaderboard": leaderboard,
    })
}

///////////////////////////////////////////////////////////////////////////////////// handlers pour les put ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

func CompleteTaskHandler(c *gin.Context, db *sql.DB) {
	// 1. Récupération de l'ID depuis l'URL (ex: PUT /tasks/5/complete)
	taskIDStr := c.Param("id")
	taskID, err := strconv.Atoi(taskIDStr)
	
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "ID de tâche invalide"})
		return
	}

	// 2. Exécution de la requête avec la bonne valeur ENUM ('done')
	query := "UPDATE task SET State = 'done' WHERE ID = ?"
	
	_, err = db.Exec(query, taskID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Impossible de mettre à jour la tâche"})
		return
	}

	// 3. Envoi de la réponse de succès
	c.JSON(http.StatusOK, gin.H{"message": "Tâche marquée comme terminée !"})
}

