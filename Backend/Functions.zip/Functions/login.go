package Functions

import (
	"database/sql"
	"fmt"
	"todo-app/Modules"
)

type LeaderboardEntry struct {
    Name  string `json:"name"`
    Level int    `json:"lvl"`
}

func Login(db *sql.DB, identifier string, plainPassword string) (*Modules.User, error) {
	u := &Modules.User{}
	var hashedPassword string // On garde cette variable locale pour ne pas exposer le hash au client

	// 1. Correction des noms de colonnes : Mail et Mdp
	query := `
		SELECT ID, Name, Mail, Mdp, Lvl, Exp, ExpNext 
		FROM users 
		WHERE Name = ? OR Mail = ?`
	
	// 2. Scan direct dans u.Email
	err := db.QueryRow(query, identifier, identifier).Scan(
		&u.ID, &u.Name, &u.Email, &hashedPassword, &u.Lvl, &u.Exp, &u.ExpNext,
	)
	
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("identifiants incorrects")
		}
		return nil, err
	}

	// 3. Vérification du mot de passe
	if !CheckPasswordHash(plainPassword, hashedPassword) {
		return nil, fmt.Errorf("identifiants incorrects")
	}

	return u, nil
}

func GetTasksByID(db *sql.DB, UserID int) ([]Modules.Task, error) {
	// Initialisation du tableau vide
	var tasks []Modules.Task

	// Correction de la requête : Description au lieu de Des
	query := `
		SELECT ID, ID_User, Name, Description, Due_Date, Duration, Priority, State, Exp_Reward 
		FROM task 
		WHERE ID_User = ?`

	// Utilisation de db.Query pour récupérer potentiellement plusieurs lignes
	rows, err := db.Query(query, UserID)
	if err != nil {
		return nil, err
	}
	defer rows.Close() // Indispensable : libère la connexion à la base de données après la boucle

	// On parcourt chaque ligne retournée par la base de données
	for rows.Next() {
		var t Modules.Task // Variable temporaire pour stocker UNE tâche

		err := rows.Scan(
			&t.ID, &t.UserID, &t.Name, &t.Des, &t.Due_Date, &t.Duration, &t.Priority, &t.State, &t.ExpReward,
		)
		if err != nil {
			return nil, err
		}

		// On ajoute la tâche remplie à notre tableau final
		tasks = append(tasks, t)
	}

	// Bonne pratique : vérifier si une erreur s'est produite durant la boucle
	if err = rows.Err(); err != nil {
		return nil, err
	}

	// Si tout s'est bien passé, on renvoie le tableau rempli
	return tasks, nil
}

func GetLeaderboard(db *sql.DB) ([]LeaderboardEntry, error) {
    // On récupère uniquement le nom et le niveau, triés par niveau décroissant
    query := "SELECT Name, Lvl FROM users ORDER BY Lvl DESC LIMIT 10"
    
    rows, err := db.Query(query)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var leaderboard []LeaderboardEntry
    for rows.Next() {
        var entry LeaderboardEntry
        if err := rows.Scan(&entry.Name, &entry.Level); err != nil {
            return nil, err
        }
        leaderboard = append(leaderboard, entry)
    }

    return leaderboard, nil
}
