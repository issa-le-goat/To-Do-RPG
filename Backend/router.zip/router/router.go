package router

import (
	"database/sql"
	"github.com/gin-gonic/gin"
	"todo-app/Functions"
)

func SetupRouter(db *sql.DB) *gin.Engine {
	r := gin.Default()

	// Groupe de routes pour les utilisateurs
	userRoutes := r.Group("/users")
	{
		// Quand un POST arrive sur /users/register, on appelle RegisterHandler
		userRoutes.POST("/register", func(c *gin.Context) { 
			Functions.RegisterHandler(c, db) 
		})

		userRoutes.POST("/login", func(c *gin.Context) {
			Functions.LoginHandler(c, db)
		})
	}

	return r
}